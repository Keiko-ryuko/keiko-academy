const scriptURL = 'https://script.google.com/macros/s/AKfycbxRnT8CzSu5w6-w-aVUGotG5JGVyFT_S2QjDlXjs94kxP7LXn_L-ah_2ZF8y3QcRLqKYw/exec'

const form = document.forms['contact-form']

form.addEventListener('submit', e => {
  e.preventDefault()
  fetch(scriptURL, { method: 'POST', body: new FormData(form)})
  .then(response => alert("Thank you! your form is submitted successfully." ))
  .then(() => { window.location.reload(); })
  .catch(error => console.error('Error!', error.message))
})